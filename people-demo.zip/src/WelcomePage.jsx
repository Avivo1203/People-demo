import React, { useState } from "react";
import "./index.css"; // או './styles.css' אם השתמשת בזה
export default function WelcomePage({ onEnter, onGuestEnter, onViewerEnter }) {
  const [mode, setMode] = useState("signIn"); // 'signIn' | 'signUp'
  const [form, setForm] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
  });

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();

    if (mode === "signIn") {
      if (!form.email || !form.password) {
        alert("נא למלא אימייל וסיסמה");
        return;
      }
      const user = {
        nickname: form.email.split("@")[0] || "משתמש",
        firstName: form.email,
        lastName: "",
        contact: form.email,
      };
      localStorage.setItem("user", JSON.stringify(user));
    } else {
      // signUp
      if (!form.firstName || !form.email || !form.password) {
        alert("נא למלא שם פרטי, אימייל וסיסמה");
        return;
      }
      const user = {
        nickname: form.firstName,
        firstName: form.firstName,
        lastName: form.lastName || "",
        contact: form.email,
      };
      localStorage.setItem("user", JSON.stringify(user));
    }

    localStorage.setItem("entered", "true");
    localStorage.setItem("guest", "false");
    localStorage.setItem("viewer", "false");
    onEnter();
  };

  return (
    <div className="wp-root">
<div className={`wp-container ${mode === "signUp" ? "wp-right-active" : ""}`}>
        {/* Sign Up */}
        <div className="wp-form wp-sign-up">
          <form onSubmit={handleSubmit}>
            <h1>הרשמה</h1>
            <input
              className="wp-input"
              type="text"
              name="firstName"
              placeholder="שם פרטי"
              value={form.firstName}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="text"
              name="lastName"
              placeholder="שם משפחה"
              value={form.lastName}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="email"
              name="email"
              placeholder="אימייל"
              value={form.email}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="password"
              name="password"
              placeholder="סיסמה"
              value={form.password}
              onChange={onChange}
            />
            <button className="wp-btn" type="submit">צור חשבון</button>
          </form>
        </div>

        {/* Sign In */}
        <div className="wp-form wp-sign-in">
          <form onSubmit={handleSubmit}>
            <h1>התחברות</h1>
            <input
              className="wp-input"
              type="email"
              name="email"
              placeholder="אימייל"
              value={form.email}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="password"
              name="password"
              placeholder="סיסמה"
              value={form.password}
              onChange={onChange}
            />
            <button className="wp-btn" type="submit">🚀 התחבר</button>

            <div className="wp-quick-actions">
              <button type="button" className="wp-btn ghost" onClick={onGuestEnter}>👤 כניסה כאורח</button>
              <button type="button" className="wp-btn ghost secondary" onClick={onViewerEnter}>👁️ מצב צפייה</button>
            </div>
          </form>
        </div>

        {/* Overlay */}
        <div className="wp-overlay-container">
          <div className="wp-overlay">
            <div className="wp-overlay-panel wp-left">
              <h2>ברוך השב!</h2>
              <p>כבר יש לך חשבון? היכנס כאן</p>
              <button className="wp-btn ghost light" onClick={() => setMode("signIn")}>
                מעבר למסך התחברות
              </button>
            </div>
            <div className="wp-overlay-panel wp-right">
              <h2>שלום חבר!</h2>
              <p>אין לך חשבון? הירשם והצטרף לקהילה</p>
              <button className="wp-btn ghost light" onClick={() => setMode("signUp")}>
                מעבר להרשמה
              </button>
            </div>
          </div>
        </div>
      </div>  
    </div>
  );
}
