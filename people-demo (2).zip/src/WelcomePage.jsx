import React, { useState } from "react";
import "./WelcomePage.css";

export default function WelcomePage({ onEnter, onGuestEnter, onViewerEnter }) {
  const [mode, setMode] = useState("signIn");
  const [form, setForm] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
  });

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();

    if (mode === "signIn") {
      if (!form.email || !form.password) {
        alert("נא למלא אימייל וסיסמה");
        return;
      }
      const user = {
        nickname: form.email.split("@")[0] || "משתמש",
        firstName: form.email,
        lastName: "",
        contact: form.email,
      };
      localStorage.setItem("user", JSON.stringify(user));
    } else {
      if (!form.firstName || !form.email || !form.password) {
        alert("נא למלא שם פרטי, אימייל וסיסמה");
        return;
      }
      const user = {
        nickname: form.firstName,
        firstName: form.firstName,
        lastName: form.lastName || "",
        contact: form.email,
      };
      localStorage.setItem("user", JSON.stringify(user));
    }

    localStorage.setItem("entered", "true");
    localStorage.setItem("guest", "false");
    localStorage.setItem("viewer", "false");
    onEnter();
  };

  return (
    <div className="wp-root">
      {/* כותרת עליונה People+ */}
      <div className="wp-header">
        <h1 className="wp-logo">People+</h1>
        <p className="wp-tagline">חיבורים לפי מיקום – אנשים סביבך בלייב</p>
      </div>

      <div className={`wp-container ${mode === "signUp" ? "wp-right-active" : ""}`}>
        {/* Sign Up */}
        <div className="wp-form wp-sign-up">
          <form onSubmit={handleSubmit}>
            
            <input
              className="wp-input"
              type="text"
              name="lastName"
              placeholder="שם משפחה"
              value={form.lastName}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="email"
              name="email"
              placeholder="אימייל"
              value={form.email}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="password"
              name="password"
              placeholder="סיסמה"
              value={form.password}
              onChange={onChange}
            />
            <button className="wp-btn login" type="submit">→ התחבר</button>
          </form>
        </div>

        {/* Sign In */}
        <div className="wp-form wp-sign-in">
          <form onSubmit={handleSubmit}>
            <h1>התחברות</h1>
            <input
              className="wp-input"
              type="email"
              name="email"
              placeholder="אימייל"
              value={form.email}
              onChange={onChange}
            />
            <input
              className="wp-input"
              type="password"
              name="password"
              placeholder="סיסמה"
              value={form.password}
              onChange={onChange}
            />

            <button className="wp-btn login" type="submit">→</button>

            <div className="wp-quick-actions">
              <button type="button" className="wp-btn ghost" onClick={onGuestEnter}>👤 כניסה כאורח</button>
              <button type="button" className="wp-btn ghost secondary" onClick={onViewerEnter}>👁️ מצב צפייה</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
